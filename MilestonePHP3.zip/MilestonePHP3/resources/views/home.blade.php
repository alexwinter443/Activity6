@extends('layouts/layout')
<html>
<body>

</body>
</html>