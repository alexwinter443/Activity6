@extends('layouts/layout')
@section('content')

	<h3>Admin Management Tool</h3>
	<a href="">Manage User</a><br>
	<a href="createGroup">Create new Group</a><br>
	<a href="adminViewGroup">View Groups</a>
	
@endsection